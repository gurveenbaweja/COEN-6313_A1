import data_model_pb2
import requests

request_For_Workload_ID = int(input('Enter Request for Workload ID (integer value): '))
benchmark_Type = input('Enter Benchmark Type (write as it is)\n1. DVD\n2. NDBench\n')
workload_Metric = input('Enter the Workload Metric (write as it is)\n1. CPUUtilization_Average\n2. NetworkIn_Average\n3. NetworkOut_Average\n4. MemoryUtilization_Average\n')
batch_Unit = int(input('Enter the number of samples to be contained in each batch (Batch Unit, integer value): '))
batch_ID = int(input('Enter the starting batch ID (integer value): '))
batch_Size = int(input('Enter the number of batches to be returned (batch size, integer value): '))
data_Type = input('Enter the type of data (write as it is)\n1. training\n2. testing\n')
data_Analytics = input('\nEnter 10p for 10th percentile, 50p for 50th percentile, 95p for 95th percentile, 99p for 99th percentile, avg for average, std for standard deviation, max for maximum value or min for minimum value: \n')
analysis_key = 'data_Analysis_' + str(data_Analytics)

data_Request = data_model_pb2.Request()

data_Request.request_For_Workload_ID = request_For_Workload_ID
data_Request.benchmark_Type = benchmark_Type
data_Request.workload_Metric = workload_Metric
data_Request.batch_Unit = batch_Unit
data_Request.batch_ID = batch_ID
data_Request.batch_Size = batch_Size
data_Request.data_Type = data_Type
data_Request.data_Analytics = data_Analytics

response = requests.get("http://3.17.154.104:5000//get_response?", headers={'Content-Type':'application/protobuf'},
                        data=data_Request.SerializeToString())

result = data_model_pb2.Response.FromString(response.content)

file = open('Protobuf_Data', 'wb')
file.write(response.content)
file.close()

print(result)