import pandas as pd
import numpy as np
import statistics

class ResponseBatch:
    def __init__(self, request_For_Workload_ID, benchmark_Type, workload_Metric, batch_Unit, batch_ID, batch_Size, data_Type, data_Analysis):
        self.request_For_Workload_ID = request_For_Workload_ID
        self.benchmark_Type = benchmark_Type
        self.workload_Metric = workload_Metric
        self.batch_Unit = batch_Unit
        self.batch_ID = batch_ID
        self.batch_Size = batch_Size
        self.data_Type = data_Type
        self.data_Analysis = data_Analysis
        self.raw_Data = pd.read_csv("https://raw.githubusercontent.com/haniehalipour/Online-Machine-Learning-for-Cloud-Resource-Provisioning-of-Microservice-Backend-Systems/master/Workload%20Data/" + self.benchmark_Type + '-' + self.data_Type + ".csv")

    def get_Data_Batches(self):
        column_Data = self.raw_Data[self.workload_Metric]
        response_Batches = []
        batch_id = self.batch_ID
        for i in range(0 , self.batch_Size):
            batch = column_Data[batch_id*self.batch_Unit : (batch_id+1)*self.batch_Unit].to_dict()
            response_Batches.append(batch)
            batch_id = batch_id+1
        last_Batch_ID = batch_id-1
        return response_Batches, last_Batch_ID
    
    def get_Data_Analytics(self):
        (data_Samples, last_Batch_ID) = self.get_Data_Batches()
        data=[]
        for i in data_Samples:
            l = list(i.values())
            for x in l:
                data.append(x)
        if self.data_Analysis == '10p':
            analysis = np.percentile(data, 10)
        elif self.data_Analysis == '50p':
            analysis = np.percentile(data, 50)
        elif self.data_Analysis == '95p':
            analysis = np.percentile(data, 95)
        elif self.data_Analysis == '99p':
            analysis = np.percentile(data, 99)
        elif self.data_Analysis == 'avg':
            analysis = np.average(data)
        elif self.data_Analysis == 'std':
            analysis = statistics.pstdev(data)
        elif self.data_Analysis == 'max':
            analysis = max(data)
        else:
            analysis = min(data)

        return analysis

    def get_Response(self):
        (data_Samples,last_Batch_ID) = self.get_Data_Batches()
        analysis_key = 'data_Analysis_' + str(self.data_Analysis)
        analysis_value = self.get_Data_Analytics()
        result = {
            'request_For_Workload_ID':self.request_For_Workload_ID,
            'last_Batch_ID':last_Batch_ID,
            'data_Samples':data_Samples
        }
        result[analysis_key] = analysis_value
        return result

    def get_Response_For_Binary(self):
        (data_Samples, last_Batch_ID) = self.get_Data_Batches()
        for sample in data_Samples:
            keys = list(sample.keys())
            for i in keys:
                sample[i] = str(i) + ": " + str(sample[i])
        analysis_key = 'data_Analysis'
        analysis_value = f'The {self.data_Analysis} value of all the samples is: {self.get_Data_Analytics()}'
        result = {
            'request_For_Workload_ID':self.request_For_Workload_ID,
            'last_Batch_ID':last_Batch_ID,
            'data_Samples':data_Samples
        }
        result[analysis_key] = analysis_value
        return result