from flask import Flask, request
import data_model_pb2
from Response_Batches import ResponseBatch

app = Flask(__name__)

@app.route('/get_response', methods=['GET'])
def get_response():
    request_Data = data_model_pb2.Request.FromString(request.data)
    result = ResponseBatch(request_Data.request_For_Workload_ID, request_Data.benchmark_Type, request_Data.workload_Metric,
                           request_Data.batch_Unit, request_Data.batch_ID, request_Data.batch_Size, request_Data.data_Type,
                           request_Data.data_Analytics)

    result_data = result.get_Response_For_Binary()

    response_data = data_model_pb2.Response()
    response_data.request_For_Workload_ID = result_data['request_For_Workload_ID']
    response_data.last_Batch_ID = result_data['last_Batch_ID']
    response_data.data_Analysis = result_data['data_Analysis']

    data_Samples = result_data['data_Samples']

    for sample in data_Samples:
        protobuf_Sample = data_model_pb2.data_sample()
        data_Array = []
        for i in range(0, len(sample)):
            data_Array.append(sample[list(sample.keys())[i]])
        protobuf_Sample.row_value[:] = data_Array
        response_data.data_Samples.append(protobuf_Sample)

    if response_data is not None and response_data.last_Batch_ID is not None:
        serialized_response = response_data.SerializeToString()
        return serialized_response


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)