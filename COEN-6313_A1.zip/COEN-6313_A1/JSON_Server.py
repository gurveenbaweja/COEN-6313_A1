from flask import Flask, request, json
from Response_Batches import ResponseBatch

app = Flask(__name__)
app.secret_key = 'cloud_assignment'

@app.route('/get_response', methods = ['GET'])
def get_response():
    request_For_Workload_ID = request.json['request_For_Workload_ID']
    benchmark_Type = request.json['benchmark_Type']
    workload_Metric = request.json['workload_Metric']
    batch_Unit = request.json['batch_Unit']
    batch_ID = request.json['batch_ID']
    batch_Size = request.json['batch_Size']
    data_Type = request.json['data_Type']
    data_Analysis = request.json['data_Analysis']

    response_Batches = ResponseBatch(request_For_Workload_ID, benchmark_Type, workload_Metric, batch_Unit, batch_ID, batch_Size, data_Type, data_Analysis)

    server_reply = response_Batches.get_Response()
    if server_reply is not None:
        return json.dumps(server_reply)

if __name__=='__main__':
    app.run(host='0.0.0.0', port=5000)