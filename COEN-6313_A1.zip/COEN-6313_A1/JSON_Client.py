import requests
import json
request_For_Workload_ID = int(input('Enter Request for Workload ID (integer value): '))
benchmark_Type = input('Enter Benchmark Type (write as it is)\n1. DVD\n2. NDBench\n')
workload_Metric = input('Enter the Workload Metric (write as it is)\n1. CPUUtilization_Average\n2. NetworkIn_Average\n3. NetworkOut_Average\n4. MemoryUtilization_Average\n')
batch_Unit = int(input('Enter the number of samples to be contained in each batch (Batch Unit, integer value): '))
batch_ID = int(input('Enter the starting batch ID (integer value): '))
batch_Size = int(input('Enter the number of batches to be returned (batch size, integer value): '))
data_Type = input('Enter the type of data (write as it is)\n1. training\n2. testing\n')
data_Analysis = input('\nEnter 10p for 10th percentile, 50p for 50th percentile, 95p for 95th percentile, 99p for 99th percentile, avg for average, std for standard deviation, max for maximum value or min for minimum value: \n')
analysis_key = 'data_Analysis_' + str(data_Analysis)
response = requests.get("http://3.17.154.104:5000/get_response?", json={
    'request_For_Workload_ID':request_For_Workload_ID,
    'benchmark_Type':benchmark_Type,
    'workload_Metric':workload_Metric,
    'batch_Unit':batch_Unit,
    'batch_ID':batch_ID,
    'batch_Size':batch_Size,
    'data_Type':data_Type,
    'data_Analysis':data_Analysis
})

if response.status_code == 200:
    with open("Json_Data.json", "w") as outfile:

        outfile.write(json.dumps(response.json(), indent=4))
    print('request_For_Workload_ID:', response.json()['request_For_Workload_ID'])
    print('\nlast_Batch_ID:', response.json()['last_Batch_ID'])
    print('\ndata_Samples:', response.json()['data_Samples'])
    print('\ndata_Analysis_',data_Analysis,': ', response.json()[analysis_key])
else:
    print('Something went wrong, No Response')